package com.database.group6.po;

public class Major {

	private String mid;
	private String mname;
	
	public String getMajorNum() {
		return mid;
	}
	public String getMajorName() {
		return mname;
	}
}
