package com.database.group6.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.database.group6.po.Course;
//import com.database.group6.po.Student;
//import com.yangcun.util.StringUtil;
//import com.yangcun.model.Sinfo;

//import com.yangcun.util.StringUtil;

public class Student {
	public ResultSet StudentList(Connection con) throws SQLException
	{
		StringBuffer sb=new StringBuffer("select * from t_sinfo ");
/**if(sinfo.getSno()!=-1){
	sb.append(" and Sno="+sinfo.getSno());
}
if(StringUtil.isNotEmpty(sinfo.getSname())){
	sb.append(" and Sname like '%"+sinfo.getSname()+"%'");
}
*/
        PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
                 return pstmt.executeQuery();
     }
	
public ResultSet PasswordList(Connection con,Student student)throws SQLException
 {
	StringBuffer sb=new StringBuffer("select * from t_slogon ");
	
		PreparedStatement pstmt=con.prepareStatement(sb.toString());
		return pstmt.executeQuery();
	
 }
    public int PasswordModify(Connection con,Student student)throws Exception
    {
	String sql="update t_slogon set Spassword=? where Sno=? ";
	PreparedStatement pstmt=con.prepareStatement(sql);
	pstmt.setString(1, student.getSpassword());
	
	return pstmt.executeUpdate();
	}

	private String getSpassword() {
		// TODO Auto-generated method stub
		return null;
	} 

}