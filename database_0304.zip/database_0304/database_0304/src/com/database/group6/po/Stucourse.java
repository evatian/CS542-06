package com.database.group6.po;

public class Stucourse {
	private String snum;
	private String cnum1;
	private String cnum2;
	private String cnum3;
	public String getStudentsNum() {
		return snum;
	}
	public String getCourseNum1() {
		return cnum1;
	}
	public void setCourseNum1(String cnum1) {
		this.cnum1 = cnum1;
	}
	public String getCourseNum2() {
		return cnum2;
	}
	public void setCourseNum2(String cnum2) {
		this.cnum2 = cnum2;
	}
	public String getCourseNum3() {
		return cnum3;
	}
	public void setCourseNum3(String cnum3) {
		this.cnum3 = cnum3;
	}
}